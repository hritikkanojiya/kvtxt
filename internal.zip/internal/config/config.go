package config

import (
	"errors"
	"os"
)

type Config struct {
	AppPort          string
	DatabaseFilePath string
	EncryptionKey    string
	MaxPayloadSize   string
}

func Load() (*Config, error) {
	cfg := &Config{
		AppPort:          os.Getenv("KVTXT_ADDR"),
		DatabaseFilePath: os.Getenv("KVTXT_DB_PATH"),
		EncryptionKey:    os.Getenv("KVTXT_ENCRYPTION_KEY"),
		MaxPayloadSize:   os.Getenv("KVTXT_MAX_PAYLOAD_SIZE"),
	}

	if cfg.AppPort == "" {
		cfg.AppPort = ":8080"
	}

	if cfg.DatabaseFilePath == "" {
		return nil, errors.New("KVTXT_DB_PATH is required")
	}

	if cfg.EncryptionKey == "" {
		return nil, errors.New("KVTXT_ENCRYPTION_KEY is required")
	}

	return cfg, nil
}
