package version

const Version = "0.1.0"
